import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses-home',
  templateUrl: './courses-home.component.html',
  styleUrls: ['./courses-home.component.scss']
})
export class CoursesHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
