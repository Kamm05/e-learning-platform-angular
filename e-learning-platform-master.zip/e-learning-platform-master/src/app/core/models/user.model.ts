export interface User {
    id: number;
    fakeToken: string;
    name: User;
    login: string;
    password: string;
}
